import React from 'react';
import { Provider } from 'react-redux';
import store from './store';
import ChatInterface from './chatInterface';

const App = () => {
  return (
    <Provider store={store}>
      <ChatInterface />
    </Provider>
  );
};

export default App;