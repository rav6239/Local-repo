// src/ChatInterface.js
import React, { useEffect, useRef, useState } from 'react';
import { Box, TextField, Button, Typography } from '@mui/material';
import { useSelector, useDispatch } from 'react-redux';
import { sendMessage, receiveMessage } from './chatSlice';

const ChatInterface = () => {
  const dispatch = useDispatch();
  const messages = useSelector((state) => state.chat.messages);
  const [message, setMessage] = useState('');
  const endOfMessagesRef = useRef(null);

  const handleSendMessage = () => {
    if (message.trim()) {
      dispatch(sendMessage(message));
      setMessage('');
      simulateMessageReception();
    }
  };

  const simulateMessageReception = () => {
    setTimeout(() => {
      dispatch(receiveMessage('This is a simulated response!'));
    }, 1000);
  };

  useEffect(() => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <Box sx={{ height: '100vh', display: 'flex', flexDirection: 'column', padding: 2 }}>
      <Box sx={{ flex: 1, overflowY: 'auto', border: '1px solid #ccc', borderRadius: '4px', padding: 2 }}>
        {messages.map((msg, index) => (
          <Box key={index} sx={{ marginBottom: 1 }}>
            <Typography variant="body2" color={msg.sender === 'User  1' ? 'primary.main' : 'secondary.main'}>
              {msg.sender}: {msg.text} <span style={{ fontSize: '0.8em', color: 'gray' }}>({msg.timestamp})</span>
            </Typography>
          </Box>
        ))}
        <div ref={endOfMessagesRef} />
      </Box>
      <Box sx={{ display: 'flex', marginTop: 2 }}>
        <TextField
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          label="Type a message"
          variant="outlined"
          fullWidth
        />
        <Button variant="contained" onClick={handleSendMessage} sx={{ marginLeft: 1 }}>
          Send
        </Button>
      </Box>
    </Box>
  );
};

export default ChatInterface;