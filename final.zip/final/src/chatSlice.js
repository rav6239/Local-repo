// src/chatSlice.js
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  messages: [],
  currentUser: 'User1', // Correctly define the current user as a string
};

const chatSlice = createSlice({
  name: 'chat',
  initialState,
  reducers: {
    sendMessage(state, action) {
      state.messages.push({
        text: action.payload,
        sender: state.currentUser, // Access the current user correctly
        timestamp: new Date().toLocaleTimeString(),
      });
    },
    receiveMessage(state, action) {
      state.messages.push({
        text: action.payload,
        sender: 'User  2',
        timestamp: new Date().toLocaleTimeString(),
      });
    },
  },
});

export const { sendMessage, receiveMessage } = chatSlice.actions;
export default chatSlice.reducer;